package com.awesomeqa.pages;

import com.awesomeqa.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.List;

public class SearchPage {
    private WebDriver driver;
    
    @FindBy(css = "div.product-layout")
    private List<WebElement> searchResults;
    
    @FindBy(css = "div#content p")
    private WebElement noResultsMessage;
    
    @FindBy(id = "input-search")
    private WebElement searchCriteriaInput;
    
    @FindBy(id = "button-search")
    private WebElement searchButton;
    
    public SearchPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public int getSearchResultsCount() {
        return searchResults.size();
    }
    
    public String getNoResultsMessage() {
        try {
            return noResultsMessage.getText();
        } catch (Exception e) {
            return "Results found";
        }
    }
    
    public boolean isSearchPageDisplayed() {
        return driver.getTitle().contains("Search") || 
               driver.getCurrentUrl().contains("search");
    }
    
    public void searchWithinResults(String criteria) {
        searchCriteriaInput.clear();
        searchCriteriaInput.sendKeys(criteria);
        searchButton.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void addProductToCartFromResults(int index) {
        if (index < searchResults.size()) {
            WebElement addToCartButton = searchResults.get(index).findElement(By.cssSelector("button[onclick*='cart.add']"));
            addToCartButton.click();
            WaitUtils.waitForElementVisible(driver, By.cssSelector("div.alert-success"));
        }
    }
}