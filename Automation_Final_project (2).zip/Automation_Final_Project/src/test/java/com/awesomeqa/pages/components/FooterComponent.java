package com.awesomeqa.pages.components;

import com.awesomeqa.utils.WaitUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FooterComponent {
    private WebDriver driver;
    
    @FindBy(linkText = "About Us")
    private WebElement aboutUsLink;
    
    @FindBy(linkText = "Delivery Information")
    private WebElement deliveryInfoLink;
    
    @FindBy(linkText = "Privacy Policy")
    private WebElement privacyPolicyLink;
    
    @FindBy(linkText = "Terms & Conditions")
    private WebElement termsConditionsLink;
    
    @FindBy(linkText = "Contact Us")
    private WebElement contactUsLink;
    
    @FindBy(linkText = "Returns")
    private WebElement returnsLink;
    
    @FindBy(linkText = "Site Map")
    private WebElement siteMapLink;
    
    @FindBy(linkText = "Brands")
    private WebElement brandsLink;
    
    @FindBy(linkText = "Gift Certificates")
    private WebElement giftCertificatesLink;
    
    @FindBy(linkText = "Affiliate")
    private WebElement affiliateLink;
    
    @FindBy(linkText = "Specials")
    private WebElement specialsLink;
    
    public FooterComponent(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public void clickAboutUs() {
        aboutUsLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickDeliveryInformation() {
        deliveryInfoLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickPrivacyPolicy() {
        privacyPolicyLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickTermsConditions() {
        termsConditionsLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickContactUs() {
        contactUsLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickReturns() {
        returnsLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickSiteMap() {
        siteMapLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickBrands() {
        brandsLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickGiftCertificates() {
        giftCertificatesLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickAffiliate() {
        affiliateLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickSpecials() {
        specialsLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public boolean isAboutUsDisplayed() {
        return aboutUsLink.isDisplayed();
    }
    
    public boolean isContactUsDisplayed() {
        return contactUsLink.isDisplayed();
    }
    
    public boolean isBrandsDisplayed() {
        return brandsLink.isDisplayed();
    }
    
    public boolean isDeliveryInfoDisplayed() {
        return deliveryInfoLink.isDisplayed();
    }
    
    public boolean isPrivacyPolicyDisplayed() {
        return privacyPolicyLink.isDisplayed();
    }
}