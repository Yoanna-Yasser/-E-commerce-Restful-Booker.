package com.awesomeqa.pages;

import com.awesomeqa.utils.WaitUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
    private WebDriver driver;
    
    @FindBy(id = "input-email")
    private WebElement emailInput;
    
    @FindBy(id = "input-password")
    private WebElement passwordInput;
    
    @FindBy(css = "input[value='Login']")
    private WebElement loginButton;
    
    @FindBy(css = "div.alert-danger")
    private WebElement errorMessage;
    
    @FindBy(linkText = "Forgotten Password")
    private WebElement forgotPasswordLink;
    
    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public void login(String email, String password) {
        emailInput.sendKeys(email);
        passwordInput.sendKeys(password);
        loginButton.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public String getErrorMessage() {
        try {
            return errorMessage.getText();
        } catch (Exception e) {
            return "No error message displayed";
        }
    }
    
    public boolean isLoginPageDisplayed() {
        return driver.getTitle().contains("Account Login") || 
               driver.getCurrentUrl().contains("route=account/login");
    }
    
    public void clickForgotPassword() {
        forgotPasswordLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
}