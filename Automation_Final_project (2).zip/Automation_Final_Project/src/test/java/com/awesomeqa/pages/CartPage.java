package com.awesomeqa.pages;

import com.awesomeqa.utils.WaitUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.List;

public class CartPage {
    private WebDriver driver;
    
    @FindBy(css = "div.table-responsive tbody tr")
    private List<WebElement> cartItems;
    
    @FindBy(css = "button[data-original-title='Remove']")
    private List<WebElement> removeButtons;
    
    @FindBy(css = "div#content p")
    private WebElement emptyCartMessage;
    
    @FindBy(linkText = "Continue Shopping")
    private WebElement continueShoppingButton;
    
    @FindBy(linkText = "Checkout")
    private WebElement checkoutButton;
    
    public CartPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public int getCartItemsCount() {
        return cartItems.size();
    }
    
    public String getEmptyCartMessage() {
        try {
            return emptyCartMessage.getText();
        } catch (Exception e) {
            return "Cart is not empty";
        }
    }
    
    public boolean isCartPageDisplayed() {
        return driver.getTitle().contains("Shopping Cart") || 
               driver.getCurrentUrl().contains("cart");
    }
    
    public void removeFirstItemFromCart() {
        if (!removeButtons.isEmpty()) {
            removeButtons.get(0).click();
            WaitUtils.waitForPageLoad(driver);
        }
    }
    
    public void clickContinueShopping() {
        continueShoppingButton.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickCheckout() {
        checkoutButton.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public boolean isCartEmpty() {
        return cartItems.isEmpty();
    }
}