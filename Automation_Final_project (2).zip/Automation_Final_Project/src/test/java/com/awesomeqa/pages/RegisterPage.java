package com.awesomeqa.pages;

import com.awesomeqa.utils.WaitUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPage {
    private WebDriver driver;
    
    @FindBy(id = "input-firstname")
    private WebElement firstNameInput;
    
    @FindBy(id = "input-lastname")
    private WebElement lastNameInput;
    
    @FindBy(id = "input-email")
    private WebElement emailInput;
    
    @FindBy(id = "input-telephone")
    private WebElement telephoneInput;
    
    @FindBy(id = "input-password")
    private WebElement passwordInput;
    
    @FindBy(id = "input-confirm")
    private WebElement confirmPasswordInput;
    
    @FindBy(name = "agree")
    private WebElement privacyPolicyCheckbox;
    
    @FindBy(css = "input[value='Continue']")
    private WebElement continueButton;
    
    @FindBy(css = "div.alert-danger")
    private WebElement errorMessage;
    
    @FindBy(css = "div.alert-success")
    private WebElement successMessage;
    
    public RegisterPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public void register(String firstName, String lastName, String email, String telephone, String password) {
        firstNameInput.sendKeys(firstName);
        lastNameInput.sendKeys(lastName);
        emailInput.sendKeys(email);
        telephoneInput.sendKeys(telephone);
        passwordInput.sendKeys(password);
        confirmPasswordInput.sendKeys(password);
        privacyPolicyCheckbox.click();
        continueButton.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public boolean isRegisterPageDisplayed() {
        return driver.getTitle().contains("Register") || 
               driver.getCurrentUrl().contains("route=account/register");
    }
    
    public String getErrorMessage() {
        try {
            return errorMessage.getText();
        } catch (Exception e) {
            return "No error message displayed";
        }
    }
    
    public String getSuccessMessage() {
        try {
            return successMessage.getText();
        } catch (Exception e) {
            return "No success message displayed";
        }
    }
}