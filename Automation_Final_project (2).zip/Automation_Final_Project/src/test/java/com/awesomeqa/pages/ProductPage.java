package com.awesomeqa.pages;

import com.awesomeqa.utils.WaitUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductPage {
    private WebDriver driver;
    
    @FindBy(css = "button#button-cart")
    private WebElement addToCartButton;
    
    @FindBy(css = "button[onclick*='wishlist.add']")
    private WebElement addToWishListButton;
    
    @FindBy(css = "div.alert-success")
    private WebElement successMessage;
    
    @FindBy(css = "h1")
    private WebElement productTitle;
    
    @FindBy(css = "li.price")
    private WebElement productPrice;
    
    public ProductPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public void addToCart() {
        addToCartButton.click();
        WaitUtils.waitForElementVisible(driver, org.openqa.selenium.By.cssSelector("div.alert-success"));
    }
    
    public void addToWishList() {
        addToWishListButton.click();
        WaitUtils.waitForElementVisible(driver, org.openqa.selenium.By.cssSelector("div.alert-success"));
    }
    
    public String getProductTitle() {
        return productTitle.getText();
    }
    
    public String getProductPrice() {
        return productPrice.getText();
    }
    
    public String getSuccessMessage() {
        return successMessage.getText();
    }
    
    public boolean isProductPageDisplayed() {
        return driver.getTitle().contains("Product") || 
               !productTitle.getText().isEmpty();
    }
}