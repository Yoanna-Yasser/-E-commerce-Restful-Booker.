package com.awesomeqa.pages;

import com.awesomeqa.pages.components.FooterComponent;
import com.awesomeqa.pages.components.HeaderComponent;
import com.awesomeqa.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.List;

public class HomePage {
    private WebDriver driver;
    public HeaderComponent header;
    public FooterComponent footer;
    
    @FindBy(css = "div.product-layout")
    private List<WebElement> featuredProducts;
    
    @FindBy(css = "button[onclick*='cart.add']")
    private List<WebElement> addToCartButtons;
    
    @FindBy(css = "button[onclick*='wishlist.add']")
    private List<WebElement> addToWishListButtons;
    
    @FindBy(css = "div.alert-success")
    private WebElement successMessage;
    
    @FindBy(css = "div.alert-danger")
    private WebElement errorMessage;
    
    @FindBy(css = "div.carousel-inner")
    private WebElement imageCarousel;
    
    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.header = new HeaderComponent(driver);
        this.footer = new FooterComponent(driver);
        PageFactory.initElements(driver, this);
    }
    
    public int getFeaturedProductsCount() {
        return featuredProducts.size();
    }
    
    public void addFirstProductToCart() {
        if (!addToCartButtons.isEmpty()) {
            addToCartButtons.get(0).click();
            WaitUtils.waitForElementVisible(driver, By.cssSelector("div.alert-success"));
        }
    }
    
    public void addProductToWishList(int index) {
        if (index < addToWishListButtons.size()) {
            addToWishListButtons.get(index).click();
        }
    }
    
    public void clickProductImage(int index) {
        if (index < featuredProducts.size()) {
            WebElement image = featuredProducts.get(index).findElement(By.cssSelector("img"));
            image.click();
            WaitUtils.waitForPageLoad(driver);
        }
    }
    
    public void clickProductTitle(int index) {
        if (index < featuredProducts.size()) {
            WebElement title = featuredProducts.get(index).findElement(By.cssSelector("h4 a"));
            title.click();
            WaitUtils.waitForPageLoad(driver);
        }
    }
    
    public String getSuccessMessage() {
        return WaitUtils.waitForElementVisible(driver, 
            By.cssSelector("div.alert-success")).getText();
    }
    
    public String getErrorMessage() {
        try {
            return WaitUtils.waitForElementVisible(driver, 
                By.cssSelector("div.alert-danger")).getText();
        } catch (Exception e) {
            return "No error message found";
        }
    }
    
    public boolean isSuccessMessageDisplayed() {
        try {
            return successMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
    
    public boolean isHomePageLoaded() {
        return driver.getTitle().contains("Your Store") || 
               driver.getCurrentUrl().contains("route=common/home");
    }
    
    public boolean isImageCarouselDisplayed() {
        return imageCarousel.isDisplayed();
    }
    
    public boolean areFeaturedProductsDisplayed() {
        return !featuredProducts.isEmpty();
    }
}