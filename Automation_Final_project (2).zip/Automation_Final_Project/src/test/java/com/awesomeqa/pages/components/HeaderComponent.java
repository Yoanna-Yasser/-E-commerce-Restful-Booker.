package com.awesomeqa.pages.components;

import com.awesomeqa.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.List;

public class HeaderComponent {
    private WebDriver driver;
    
    @FindBy(css = "div#logo a")
    private WebElement logo;
    
    @FindBy(name = "search")
    private WebElement searchInput;
    
    @FindBy(css = "button.btn-light")
    private WebElement searchButton;
    
    @FindBy(css = "a[title='Shopping Cart']")
    private WebElement shoppingCart;
    
    @FindBy(css = "a[title='My Account']")
    private WebElement myAccount;
    
    @FindBy(linkText = "Register")
    private WebElement registerLink;
    
    @FindBy(linkText = "Login")
    private WebElement loginLink;
    
    @FindBy(linkText = "Wish List")
    private WebElement wishListLink;
    
    @FindBy(css = "form#form-currency button")
    private WebElement currencyDropdown;
    
    @FindBy(css = "form#form-currency ul li")
    private List<WebElement> currencyOptions;
    
    private By desktopMenu = By.linkText("Desktops");
    private By laptopsMenu = By.linkText("Laptops & Notebooks");
    private By componentsMenu = By.linkText("Components");
    private By tabletsMenu = By.linkText("Tablets");
    private By softwareMenu = By.linkText("Software");
    private By phonesMenu = By.linkText("Phones & PDAs");
    private By camerasMenu = By.linkText("Cameras");
    
    public HeaderComponent(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public void searchForProduct(String productName) {
        searchInput.clear();
        searchInput.sendKeys(productName);
        searchButton.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickDesktops() {
        WaitUtils.waitForElementClickable(driver, desktopMenu).click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickLaptops() {
        WaitUtils.waitForElementClickable(driver, laptopsMenu).click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickComponents() {
        WaitUtils.waitForElementClickable(driver, componentsMenu).click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickTablets() {
        WaitUtils.waitForElementClickable(driver, tabletsMenu).click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickSoftware() {
        WaitUtils.waitForElementClickable(driver, softwareMenu).click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickPhones() {
        WaitUtils.waitForElementClickable(driver, phonesMenu).click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickCameras() {
        WaitUtils.waitForElementClickable(driver, camerasMenu).click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickMyAccount() {
        myAccount.click();
    }
    
    public void clickRegister() {
        clickMyAccount();
        registerLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickLogin() {
        clickMyAccount();
        loginLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickWishList() {
        clickMyAccount();
        wishListLink.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void clickShoppingCart() {
        shoppingCart.click();
        WaitUtils.waitForPageLoad(driver);
    }
    
    public void changeCurrency(String currency) {
        currencyDropdown.click();
        for (WebElement option : currencyOptions) {
            if (option.getText().contains(currency)) {
                option.click();
                break;
            }
        }
    }
    
    public boolean isLogoDisplayed() {
        return logo.isDisplayed();
    }
    
    public boolean isSearchBoxDisplayed() {
        return searchInput.isDisplayed();
    }
    
    public boolean isMyAccountDisplayed() {
        return myAccount.isDisplayed();
    }
    
    public boolean isShoppingCartDisplayed() {
        return shoppingCart.isDisplayed();
    }
}