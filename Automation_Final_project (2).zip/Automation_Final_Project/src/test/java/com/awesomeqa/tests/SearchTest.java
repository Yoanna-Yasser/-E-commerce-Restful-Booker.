package com.awesomeqa.tests;

import com.awesomeqa.utils.TestBase;
import com.awesomeqa.utils.ConfigReader;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class SearchTest extends TestBase {
    
    @Test(priority = 1)
    public void testValidProductSearch() {
        homePage.header.searchForProduct(ConfigReader.getProperty("search.product.valid"));
        assertTrue(driver.getCurrentUrl().contains("search") || 
                  driver.getPageSource().contains("Search"),
                  "Should navigate to search results page");
        System.out.println("Valid product search test passed");
    }
    
    @Test(priority = 2)
    public void testInvalidProductSearch() {
        homePage.header.searchForProduct(ConfigReader.getProperty("search.product.invalid"));
        assertTrue(driver.getPageSource().contains("no product") || 
                  driver.getPageSource().contains("no results") ||
                  driver.getPageSource().contains("There is no product"),
                  "Should show no results message");
        System.out.println("Invalid product search test passed");
    }
    
    @Test(priority = 3)
    public void testEmptySearch() {
        homePage.header.searchForProduct("");
        assertTrue(driver.getPageSource().contains("product") || 
                  driver.getCurrentUrl().contains("search"),
                  "Should handle empty search appropriately");
        System.out.println("Empty search test passed");
    }
}