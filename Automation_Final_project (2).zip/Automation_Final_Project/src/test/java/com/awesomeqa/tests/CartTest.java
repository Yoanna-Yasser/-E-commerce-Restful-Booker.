package com.awesomeqa.tests;

import com.awesomeqa.utils.TestBase;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class CartTest extends TestBase {
    
    @Test(priority = 1)
    public void testAddToCart() {
        homePage.addFirstProductToCart();
        assertTrue(homePage.isSuccessMessageDisplayed() || 
                  homePage.getSuccessMessage().contains("Success"),
                  "Should show success message when adding to cart");
        System.out.println("Add to cart test passed");
    }
    
    @Test(priority = 2)
    public void testShoppingCartNavigation() {
        homePage.header.clickShoppingCart();
        assertTrue(driver.getCurrentUrl().contains("cart") || 
                  driver.getPageSource().contains("Shopping Cart"),
                  "Should navigate to shopping cart page");
        System.out.println("Shopping cart navigation test passed");
    }
}