package com.awesomeqa.tests;

import com.awesomeqa.utils.TestBase;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class NavigationTest extends TestBase {
    
    @Test(priority = 1)
    public void testHomePageLoading() {
        assertTrue(homePage.isHomePageLoaded(), "Home page should load successfully");
        System.out.println("Home page loaded successfully");
    }
    
    @Test(priority = 2)
    public void testDesktopNavigation() {
        homePage.header.clickDesktops();
        assertTrue(driver.getCurrentUrl().contains("desktop") || 
                  driver.getCurrentUrl().contains("category"),
                  "Should navigate to Desktops page");
        System.out.println("Desktop navigation test passed");
    }
    
    @Test(priority = 3)
    public void testLaptopsNavigation() {
        homePage.header.clickLaptops();
        assertTrue(driver.getCurrentUrl().contains("laptop") || 
                  driver.getCurrentUrl().contains("category"),
                  "Should navigate to Laptops page");
        System.out.println("Laptops navigation test passed");
    }
    
    @Test(priority = 4)
    public void testComponentsNavigation() {
        homePage.header.clickComponents();
        assertTrue(driver.getCurrentUrl().contains("component") || 
                  driver.getCurrentUrl().contains("category"),
                  "Should navigate to Components page");
        System.out.println("Components navigation test passed");
    }
    
    @Test(priority = 5)
    public void testMyAccountDropdown() {
        homePage.header.clickMyAccount();
        assertTrue(homePage.header.isLogoDisplayed());
        System.out.println("My Account dropdown test passed");
    }
    
    @Test(priority = 6)
    public void testSearchBoxVisibility() {
        assertTrue(homePage.header.isSearchBoxDisplayed());
        System.out.println("Search box visibility test passed");
    }
}