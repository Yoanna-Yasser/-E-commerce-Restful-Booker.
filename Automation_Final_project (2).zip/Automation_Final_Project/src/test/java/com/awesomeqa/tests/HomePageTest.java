package com.awesomeqa.tests;

import com.awesomeqa.utils.TestBase;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class HomePageTest extends TestBase {
    
    @Test(priority = 1)
    public void testHomePageLoading() {
        assertTrue(homePage.isHomePageLoaded(), "Home page should load successfully");
        System.out.println("Home page loaded successfully");
    }
    
    @Test(priority = 2)
    public void testHeaderComponents() {
        assertTrue(homePage.header.isLogoDisplayed(), "Logo should be displayed");
        assertTrue(homePage.header.isSearchBoxDisplayed(), "Search box should be displayed");
        assertTrue(homePage.header.isMyAccountDisplayed(), "My Account should be displayed");
        assertTrue(homePage.header.isShoppingCartDisplayed(), "Shopping Cart should be displayed");
        System.out.println("All header components are displayed");
    }
    
    @Test(priority = 3)
    public void testFeaturedProducts() {
        assertTrue(homePage.areFeaturedProductsDisplayed(), "Featured products should be displayed");
        assertTrue(homePage.getFeaturedProductsCount() > 0, "Should have at least one featured product");
        System.out.println("Featured products are displayed correctly");
    }
    
    @Test(priority = 4)
    public void testImageCarousel() {
        assertTrue(homePage.isImageCarouselDisplayed(), "Image carousel should be displayed");
        System.out.println("Image carousel is displayed");
    }
    
    @Test(priority = 5)
    public void testFooterComponents() {
        assertTrue(homePage.footer.isAboutUsDisplayed(), "About Us link should be displayed");
        assertTrue(homePage.footer.isContactUsDisplayed(), "Contact Us link should be displayed");
        assertTrue(homePage.footer.isBrandsDisplayed(), "Brands link should be displayed");
        assertTrue(homePage.footer.isDeliveryInfoDisplayed(), "Delivery Info link should be displayed");
        assertTrue(homePage.footer.isPrivacyPolicyDisplayed(), "Privacy Policy link should be displayed");
        System.out.println("All footer components are displayed");
    }
}