package com.awesomeqa.tests;

import com.awesomeqa.utils.TestBase;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class UserAccountTest extends TestBase {
    
    @Test(priority = 1)
    public void testLoginPageNavigation() {
        homePage.header.clickLogin();
        assertTrue(driver.getCurrentUrl().contains("login") || 
                  driver.getPageSource().contains("Login"),
                  "Should navigate to login page");
        System.out.println("Login page navigation test passed");
    }
    
    @Test(priority = 2)
    public void testRegisterPageNavigation() {
        homePage.header.clickRegister();
        assertTrue(driver.getCurrentUrl().contains("register") || 
                  driver.getPageSource().contains("Register"),
                  "Should navigate to register page");
        System.out.println("Register page navigation test passed");
    }
    
    @Test(priority = 3)
    public void testWishListNavigation() {
        homePage.header.clickWishList();
        assertTrue(driver.getCurrentUrl().contains("wishlist") || 
                  driver.getPageSource().contains("Wish List"),
                  "Should navigate to wish list page");
        System.out.println("Wish List navigation test passed");
    }
}