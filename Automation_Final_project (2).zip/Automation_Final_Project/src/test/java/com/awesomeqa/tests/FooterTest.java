package com.awesomeqa.tests;

import com.awesomeqa.utils.TestBase;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class FooterTest extends TestBase {
    
    @Test(priority = 1)
    public void testAboutUsLink() {
        homePage.footer.clickAboutUs();
        assertTrue(driver.getCurrentUrl().contains("about") || 
                  driver.getPageSource().contains("About Us"),
                  "Should navigate to About Us page");
        System.out.println("About Us link test passed");
    }
    
    @Test(priority = 2)
    public void testContactUsLink() {
        homePage.footer.clickContactUs();
        assertTrue(driver.getCurrentUrl().contains("contact") || 
                  driver.getPageSource().contains("Contact Us"),
                  "Should navigate to Contact Us page");
        System.out.println("Contact Us link test passed");
    }
    
    @Test(priority = 3)
    public void testBrandsLink() {
        homePage.footer.clickBrands();
        assertTrue(driver.getCurrentUrl().contains("brand") || 
                  driver.getPageSource().contains("Brand"),
                  "Should navigate to Brands page");
        System.out.println("Brands link test passed");
    }
    
    @Test(priority = 4)
    public void testSpecialsLink() {
        homePage.footer.clickSpecials();
        assertTrue(driver.getCurrentUrl().contains("special") || 
                  driver.getPageSource().contains("Special"),
                  "Should navigate to Specials page");
        System.out.println("Specials link test passed");
    }
}